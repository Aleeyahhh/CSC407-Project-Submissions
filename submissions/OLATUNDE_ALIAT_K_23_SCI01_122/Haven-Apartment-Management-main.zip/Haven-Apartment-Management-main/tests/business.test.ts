import test from 'node:test';
import assert from 'node:assert/strict';
import {leaseSchema,invoiceSchema,paymentSchema,unitSchema,canManage,invoiceStatus} from '../lib/rules.ts';
test('only admin and manager can manage records',()=>{assert.equal(canManage('tenant'),false);assert.equal(canManage('admin'),true);assert.equal(canManage('manager'),true)});
test('lease date ordering and real calendar dates',()=>{const l={apartmentId:'a',tenantId:'t',start:'2026-02-01',end:'2026-03-01',rent:100};assert(leaseSchema.safeParse(l).success);assert(!leaseSchema.safeParse({...l,end:'2026-01-01'}).success);assert(!leaseSchema.safeParse({...l,start:'2026-02-30'}).success)});
test('amounts must be positive whole naira',()=>{for(const amount of [-1,0,1.5,Infinity])assert(!invoiceSchema.safeParse({tenantId:'t',apartmentId:'a',description:'rent',amount,due:'2026-12-01'}).success);assert(!paymentSchema.safeParse({invoiceId:'i',amount:10,reference:'',method:'Cash'}).success)});
test('invoice status derives from totals and actual payment balance',()=>{const i={amount:100,vat:8,due:'2026-10-01'};assert.equal(invoiceStatus(i,108,'2026-10-31'),'Paid');assert.equal(invoiceStatus(i,100,'2026-10-31'),'Overdue');assert.equal(invoiceStatus(i,50,'2026-09-01'),'Part paid');assert.equal(invoiceStatus(i,0,'2026-09-01'),'Due')});
test('apartments cannot be created as occupied without a lease',()=>{assert(!unitSchema.safeParse({unit:'A1',building:'A',type:'Studio',rent:100,status:'Occupied'}).success)});

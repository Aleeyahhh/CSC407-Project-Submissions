CREATE TABLE "users" (
	"id" text PRIMARY KEY NOT NULL,
	"auth_id" text,
	"email" text NOT NULL,
	"name" text NOT NULL,
	"role" text DEFAULT 'tenant' NOT NULL,
	"phone" text DEFAULT '' NOT NULL,
	"active" integer DEFAULT 1 NOT NULL
);

CREATE UNIQUE INDEX "users_auth_id_unique" ON "users" ("auth_id");
CREATE UNIQUE INDEX "users_email_unique" ON "users" ("email");

CREATE TABLE "apartments" (
	"id" text PRIMARY KEY NOT NULL,
	"unit" text NOT NULL,
	"building" text NOT NULL,
	"type" text NOT NULL,
	"rent" bigint NOT NULL,
	"status" text DEFAULT 'Available' NOT NULL
);

CREATE UNIQUE INDEX "apartments_unit_unique" ON "apartments" ("unit");
CREATE TABLE "audit" (
	"id" text PRIMARY KEY NOT NULL,
	"actor" text NOT NULL,
	"action" text NOT NULL,
	"detail" text NOT NULL,
	"created" text NOT NULL
);

CREATE TABLE "invoices" (
	"id" text PRIMARY KEY NOT NULL,
	"tenant_id" text NOT NULL,
	"apartment_id" text NOT NULL,
	"description" text NOT NULL,
	"amount" bigint NOT NULL,
	"vat" bigint DEFAULT 0 NOT NULL,
	"due" text NOT NULL,
	"created" text NOT NULL,
	FOREIGN KEY ("tenant_id") REFERENCES "users"("id") ON UPDATE no action ON DELETE no action,
	FOREIGN KEY ("apartment_id") REFERENCES "apartments"("id") ON UPDATE no action ON DELETE no action
);

CREATE TABLE "leases" (
	"id" text PRIMARY KEY NOT NULL,
	"apartment_id" text NOT NULL,
	"tenant_id" text NOT NULL,
	"start" text NOT NULL,
	"end" text NOT NULL,
	"rent" bigint NOT NULL,
	"status" text DEFAULT 'Active' NOT NULL,
	FOREIGN KEY ("apartment_id") REFERENCES "apartments"("id") ON UPDATE no action ON DELETE no action,
	FOREIGN KEY ("tenant_id") REFERENCES "users"("id") ON UPDATE no action ON DELETE no action
);

CREATE TABLE "notices" (
	"id" text PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"body" text NOT NULL,
	"created" text NOT NULL
);

CREATE TABLE "payments" (
	"id" text PRIMARY KEY NOT NULL,
	"invoice_id" text NOT NULL,
	"amount" bigint NOT NULL,
	"reference" text NOT NULL,
	"method" text NOT NULL,
	"created" text NOT NULL,
	"recorded_by" text NOT NULL,
	FOREIGN KEY ("invoice_id") REFERENCES "invoices"("id") ON UPDATE no action ON DELETE no action
);

CREATE UNIQUE INDEX "payments_reference_unique" ON "payments" ("reference");
CREATE TABLE "requests" (
	"id" text PRIMARY KEY NOT NULL,
	"tenant_id" text NOT NULL,
	"apartment_id" text NOT NULL,
	"title" text NOT NULL,
	"description" text NOT NULL,
	"category" text NOT NULL,
	"priority" text NOT NULL,
	"status" text DEFAULT 'Open' NOT NULL,
	"assigned" text DEFAULT '' NOT NULL,
	"created" text NOT NULL,
	FOREIGN KEY ("tenant_id") REFERENCES "users"("id") ON UPDATE no action ON DELETE no action,
	FOREIGN KEY ("apartment_id") REFERENCES "apartments"("id") ON UPDATE no action ON DELETE no action
);

CREATE TABLE "settings" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text DEFAULT 'My property portfolio' NOT NULL,
	"address" text DEFAULT 'Lagos, Nigeria' NOT NULL,
	"vat" bigint DEFAULT 750 NOT NULL,
	"bank" text DEFAULT '' NOT NULL,
	"account" text DEFAULT '' NOT NULL
);

CREATE UNIQUE INDEX one_active_lease_per_unit ON leases(apartment_id) WHERE status='Active';

CREATE INDEX invoice_tenant ON invoices(tenant_id);

CREATE INDEX payment_invoice ON payments(invoice_id);

CREATE INDEX request_tenant ON requests(tenant_id);

CREATE INDEX lease_tenant ON leases(tenant_id);


CREATE OR REPLACE FUNCTION deny_audit_mutation() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Audit history is immutable'; END $$;
CREATE TRIGGER audit_immutable BEFORE UPDATE OR DELETE ON audit FOR EACH ROW EXECUTE FUNCTION deny_audit_mutation();
CREATE TABLE "user" (id text PRIMARY KEY,name text NOT NULL,email text NOT NULL UNIQUE,"emailVerified" boolean NOT NULL DEFAULT false,image text,"createdAt" timestamptz NOT NULL DEFAULT now(),"updatedAt" timestamptz NOT NULL DEFAULT now());
CREATE TABLE "session" (id text PRIMARY KEY,"expiresAt" timestamptz NOT NULL,token text NOT NULL UNIQUE,"createdAt" timestamptz NOT NULL DEFAULT now(),"updatedAt" timestamptz NOT NULL DEFAULT now(),"ipAddress" text,"userAgent" text,"userId" text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE);
CREATE TABLE account (id text PRIMARY KEY,"accountId" text NOT NULL,"providerId" text NOT NULL,"userId" text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,"accessToken" text,"refreshToken" text,"idToken" text,"accessTokenExpiresAt" timestamptz,"refreshTokenExpiresAt" timestamptz,scope text,password text,"createdAt" timestamptz NOT NULL DEFAULT now(),"updatedAt" timestamptz NOT NULL DEFAULT now());
CREATE TABLE verification (id text PRIMARY KEY,identifier text NOT NULL,value text NOT NULL,"expiresAt" timestamptz NOT NULL,"createdAt" timestamptz NOT NULL DEFAULT now(),"updatedAt" timestamptz NOT NULL DEFAULT now());
CREATE TABLE "rateLimit" (id text PRIMARY KEY,key text UNIQUE,count integer,"lastRequest" bigint);

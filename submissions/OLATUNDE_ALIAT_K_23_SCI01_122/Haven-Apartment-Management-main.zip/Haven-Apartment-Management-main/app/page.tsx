import Haven from './haven';
export const dynamic='force-dynamic';
export default function Home(){return <Haven/>}

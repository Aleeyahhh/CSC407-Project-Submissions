import {headers} from 'next/headers';
import {getAuth} from '../lib/auth';
export async function getChatGPTUser(){const s=await getAuth().api.getSession({headers:await headers()});return s?{userId:s.user.id,emailVerified:s.user.emailVerified,email:s.user.email,displayName:s.user.name}:null}

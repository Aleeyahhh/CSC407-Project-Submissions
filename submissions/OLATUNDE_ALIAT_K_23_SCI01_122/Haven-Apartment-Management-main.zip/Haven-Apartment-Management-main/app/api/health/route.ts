import {database} from '../../../lib/database';
export async function GET(){try{await database.prepare('SELECT 1').first();return Response.json({status:'ok',service:'haven',database:'connected'},{headers:{'Cache-Control':'no-store'}})}catch{return Response.json({status:'unavailable'},{status:503})}}

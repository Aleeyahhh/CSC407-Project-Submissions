import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Haven · Apartment Management',description:'Every home. In good hands. Manage apartments, residents, rent and maintenance in one considered space.',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}

'use client';
import {useEffect} from 'react';import {authClient} from '../../lib/auth-client';
export default function Page(){useEffect(()=>{authClient.signOut().then(()=>window.location.assign('/sign-in'))},[]);return <div className='loading'>Signing out…</div>}

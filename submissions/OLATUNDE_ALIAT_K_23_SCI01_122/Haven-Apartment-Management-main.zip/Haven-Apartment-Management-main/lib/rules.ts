import {z} from 'zod';
export const roles=['admin','manager','tenant'] as const;
export const str=z.string().trim().min(1).max(160);
export const amount=z.coerce.number().int().min(1).max(100000000000);
export const date=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v=>!Number.isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v,'Enter a valid date');
export const unitSchema=z.object({unit:str,building:str,type:str,rent:amount,status:z.enum(['Available','Maintenance']).default('Available')});
export const userSchema=z.object({name:str,email:z.string().email().max(160).transform(v=>v.toLowerCase()),phone:z.string().max(30).default(''),role:z.enum(roles).default('tenant')});
export const leaseSchema=z.object({apartmentId:str,tenantId:str,start:date,end:date,rent:amount}).refine(v=>v.end>v.start,'Lease end must be after its start');
export const invoiceSchema=z.object({tenantId:str,apartmentId:str,description:str,amount:amount,due:date,taxable:z.boolean().default(false)});
export const paymentSchema=z.object({invoiceId:str,amount,reference:str,method:z.enum(['Bank transfer','Cash','POS'])});
export const requestSchema=z.object({apartmentId:str,title:str,description:z.string().trim().min(10).max(3000),category:z.enum(['Plumbing','Electrical','Appliance','Building','Other']),priority:z.enum(['Normal','High','Urgent']),tenantId:z.string().optional()});
export function canManage(role:string){return role==='admin'||role==='manager'}
export function totalInvoice(i:{amount:number,vat:number}){return i.amount+i.vat}
export function invoiceStatus(i:{amount:number,vat:number,due:string},paid:number,today=new Date().toISOString().slice(0,10)){return paid>=totalInvoice(i)?'Paid':i.due<today?'Overdue':paid>0?'Part paid':'Due'}

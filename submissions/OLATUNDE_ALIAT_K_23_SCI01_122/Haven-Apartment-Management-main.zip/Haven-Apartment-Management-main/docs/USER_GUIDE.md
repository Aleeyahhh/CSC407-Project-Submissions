# User guide

Administrators: set portfolio name, location, bank instructions and optional invoice VAT in Settings. Add staff with the appropriate role. Deactivate access rather than deleting financial history. Review audit history regularly.

Managers: add apartments with annual rent and availability; add tenants using their sign-in email; create a lease, then issue rent or service invoices. Record payments only after bank/cash verification. Open invoices to view balances and receipts. Duplicate references and overpayments are rejected. Occupied apartments remain occupied until their active lease is ended.

Residents: register and verify email, then sign in. Your manager links your email record to a lease. View only your home, invoices, receipts and maintenance requests. Open an apartment to view the current lease. Report issues with category, priority and description. Track status updates and read community notices.

Use Search and status filters to find records. Reports and payment screens export CSV. Print invoice, receipt and lease dialogs to save as PDF. Sample portfolio is read-only and contains fictional examples.

# Haven Apartment Management

Next.js 16 / React 19 / TypeScript, Neon PostgreSQL and Better Auth email/password authentication. Navy, ivory and terracotta interface. Source upgrade from the earlier Sites-hosted edition; this repository does not replace that live edition automatically.

## Features

Tenant, manager and administrator roles; apartment inventory and editing; tenant contact editing; lease creation/ending and summaries; rent/service invoices with optional configurable VAT; confirmed partial payments and receipts; maintenance assignments and status updates; community notices; collection/occupancy reports; CSV exports; profile settings and immutable audit history.

Email verification, password reset and database-backed authentication rate limiting are configured with Better Auth. Required email delivery uses Resend. Every API validates identity, email verification, active-account status and role. Residents only receive their own records. The configured ADMIN_EMAIL receives the initial admin role only after verified sign-in. Registration never accepts role input.

## Setup and deployment

1. Import this private GitHub repository into Vercel.
2. Set `.env.example` keys in the project: Neon DATABASE_URL, strong BETTER_AUTH_SECRET, production BETTER_AUTH_URL, ADMIN_EMAIL, RESEND_API_KEY and verified EMAIL_FROM. Generate secrets outside chat; never commit environment files.
3. Install with `npm ci`. After project/environment configuration, apply `npm run db:migrate`. Migrations are tracked in schema_migrations and transaction protected. This is an empty new database; existing Sites records are not automatically migrated.
4. Deploy using `npm run build` / Next.js framework. Register the configured admin email, verify it, then sign in. Add apartments and tenant records; tenants sign up and verify their matching email to link their accounts.
5. Add a lease before issuing an invoice. Verify payments externally before recording them. No online payment gateway is connected.

The schema includes standard Better Auth tables. Before changing authentication plugins or versions, regenerate/review the auth schema against that installed version and use a new versioned migration. Do not rerun schema.sql manually on an initialized database.

## Checks

`npm run typecheck`, `npm test`, `npm run build`. CI runs these on pushes and pull requests. The previous SQLite edition had isolated API/DB tests; those results do not establish PostgreSQL or new-auth runtime correctness. Live multi-account verification and responsive browser tests must be completed after Vercel/environment setup. Never report the migration/deployment as complete until those pass.

## Operations

/api/health returns database availability. The operations workflow runs at 05:00 UTC (06:00 Nigeria) daily and on manual dispatch. Configure repository secrets DATABASE_URL and BACKUP_ENCRYPTION_KEY and repository variable HAVEN_URL first. It creates AES-256-GCM encrypted consistent JSON exports and retains artifacts for 14 days. Until secrets and a successful run are verified, automated backups are not operational. Keep the encryption key separately; losing it makes backups unreadable.

`npm run backup` exports domain and authentication tables from a repeatable-read snapshot. `node scripts/decrypt-backup.mjs input.enc output.json` decrypts using BACKUP_ENCRYPTION_KEY. Restoration is a controlled database operation: restore into an isolated database, load in foreign-key order, verify counts and data, invalidate restored sessions, and switch connection only after review. The export is not a PostgreSQL binary/PITR backup. Use Neon recovery as an additional provider-level safeguard.

## Current external blockers

Vercel project creation returned 403 (insufficient project creation permission) in the connected team. Neon project shiny-union-34767547 was created but schema application and environment connection await deployment configuration. No email provider credentials, backup secrets or live hosted identity flow have been configured. The previous Sites deployment remains available.
